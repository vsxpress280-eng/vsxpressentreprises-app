import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Globe, Shield, Lock, ChevronRight } from 'lucide-react';
import LanguageSwitcher from '@/components/LanguageSwitcher';

const WorkerSettings = () => {
  const navigate = useNavigate();
  const { t } = useTranslation();

  return (
    <>
      <Helmet>
        <title>{t('settings.title')} - Worker</title>
      </Helmet>

      <div className="min-h-screen bg-[#0B0B0B] p-4 sm:p-6 text-white">
        <div className="max-w-2xl mx-auto">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/worker/dashboard')} 
            className="mb-6 text-[#A0A0A0] hover:text-white pl-0"
          >
             <ArrowLeft className="w-4 h-4 mr-2" />
             {t('buttons.backToDashboard')}
          </Button>

          <h1 className="text-3xl font-bold mb-2">{t('settings.title')}</h1>
          <p className="text-[#A0A0A0] mb-8">{t('settings.subtitle', 'Gérez vos préférences et votre sécurité')}</p>

          <div className="space-y-6">
            
            {/* Language Section */}
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-[#1E1E1E] rounded-xl border border-[#2A2A2A] overflow-hidden"
            >
              <div className="p-4 border-b border-[#2A2A2A] flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-[#D4AF37]/10 flex items-center justify-center">
                  <Globe className="w-4 h-4 text-[#D4AF37]" />
                </div>
                <h2 className="font-semibold">{t('settings.language')}</h2>
              </div>
              <div className="p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                 <div>
                    <p className="font-medium text-white">{t('settings.appLanguage')}</p>
                    <p className="text-xs text-[#A0A0A0] mt-1">{t('settings.languageDesc')}</p>
                 </div>
                 <LanguageSwitcher />
              </div>
            </motion.div>

            {/* Security Section */}
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-[#1E1E1E] rounded-xl border border-[#2A2A2A] overflow-hidden"
            >
              <div className="p-4 border-b border-[#2A2A2A] flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center">
                  <Shield className="w-4 h-4 text-blue-500" />
                </div>
                <h2 className="font-semibold">{t('settings.security')}</h2>
              </div>
              <div className="divide-y divide-[#2A2A2A]">
                 <div className="p-4 hover:bg-[#252525] transition-colors cursor-pointer group" onClick={() => navigate('/profile/change-password')}>
                    <div className="flex items-center justify-between">
                       <div className="flex items-center gap-3">
                          <Lock className="w-4 h-4 text-[#A0A0A0]" />
                          <div>
                             <p className="font-medium text-sm">{t('settings.changePassword')}</p>
                             <p className="text-xs text-[#666]">{t('settings.changePasswordDesc')}</p>
                          </div>
                       </div>
                       <ChevronRight className="w-4 h-4 text-[#444] group-hover:text-white transition-colors" />
                    </div>
                 </div>

                 <div className="p-4 hover:bg-[#252525] transition-colors cursor-pointer group" onClick={() => navigate('/auth/set-security-question')}>
                    <div className="flex items-center justify-between">
                       <div className="flex items-center gap-3">
                          <Shield className="w-4 h-4 text-[#A0A0A0]" />
                          <div>
                             <p className="font-medium text-sm">{t('auth.setSecurityQuestion.title')}</p>
                             <p className="text-xs text-[#666]">{t('settings.securityQuestionDesc', 'Définir ou modifier votre question de sécurité')}</p>
                          </div>
                       </div>
                       <ChevronRight className="w-4 h-4 text-[#444] group-hover:text-white transition-colors" />
                    </div>
                 </div>
              </div>
            </motion.div>

          </div>
        </div>
      </div>
    </>
  );
};

export default WorkerSettings;